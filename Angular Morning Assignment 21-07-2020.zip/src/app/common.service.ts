import { Injectable } from '@angular/core';

@Injectable()
export class CommonService {

  constructor() { }
  num=0
  val=0
  getValue():number{
    return this.val
  }
  setValue(val:number):void{
    this.val=val
  }
  log(){
    console.log("Common Service"+this.num++)
  }
}
