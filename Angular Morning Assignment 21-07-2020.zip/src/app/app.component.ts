import { Component, OnInit, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { CommonService } from './common.service';

@Component({
  selector: 'app-root',
  
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit,OnChanges,OnDestroy{
  constructor(public commonSvc:CommonService) { 
    console.log("constructor");
  }
  ngOnDestroy(){
    console.log("Destroy")
  }
  dashboard=false
  ngOnChanges() {
    console.log("Changes")
  }
  a=[{
    id:1,
    title:'a'
  },
  {
    id:2,
    title:'b'
  },
  {
    id:3,
    title:'c'
  },
  {
    id:4,
    title:'d'
  }]
  toggle():void{
    this.dashboard=!this.dashboard
  }
  ngOnInit(): void {
    console.log("Init")
    this.commonSvc.log()
  }

  title = 'AngularRecording';
}