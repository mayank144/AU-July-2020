import { Component, OnInit, OnDestroy, OnChanges, Input } from '@angular/core';
import { CommonService } from '../common.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit ,OnDestroy,OnChanges{

  constructor(public commonSvc: CommonService) { 
    console.log("constructor")
  }
  ngOnChanges() {
    console.log("Changes")
  }

  @Input()
  num:number;
  @Input()
  title:string;

  x=new Date();
  ngOnInit(): void {
    console.log("Init")
    this.commonSvc.log()
  }

  log(str:string):void{
    console.log("Hello "+str)
  }
  ngOnDestroy(){
    console.log("Destroy")
  }

}
